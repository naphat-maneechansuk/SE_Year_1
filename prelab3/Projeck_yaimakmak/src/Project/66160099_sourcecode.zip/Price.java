package Project;

public interface Price {
    public double getPrice();
    public String getName();
}
